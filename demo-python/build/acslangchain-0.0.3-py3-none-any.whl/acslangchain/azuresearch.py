"""Wrapper around Azure Cognitive Search."""
from __future__ import annotations

import json
import logging
import uuid
from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional, Tuple, Type
from pydantic import BaseModel, root_validator


import numpy as np
from azure.core.exceptions import ResourceNotFoundError
from azure.core.credentials import AzureKeyCredential  
from azure.search.documents import SearchClient  
from azure.search.documents.indexes import SearchIndexClient  
from azure.search.documents.models import Vector  
from azure.search.documents.indexes.models import (  
    SearchIndex,  
    SearchField,  
    SearchFieldDataType,  
    SimpleField,  
    SearchableField,  
    SearchIndex,  
    SemanticConfiguration,  
    PrioritizedFields,  
    SemanticField,  
    SearchField,  
    SemanticSettings,  
    VectorSearch,  
    VectorSearchAlgorithmConfiguration,  
)  

from langchain.docstore.document import Document
from langchain.embeddings.base import Embeddings
from langchain.schema import BaseRetriever
from langchain.utils import get_from_dict_or_env
from langchain.vectorstores.base import VectorStore

logger = logging.getLogger()

def get_search_client(endpoint:str, key: str ,index_name: str):
    index_client: SearchIndexClient = SearchIndexClient(endpoint=endpoint, credential=AzureKeyCredential(key))
    try:
        index_client.get_index(name=index_name)
    except ResourceNotFoundError as ex:
        fields = [
            SimpleField(name="id", type=SearchFieldDataType.String, key=True, filterable=True),
            SearchableField(name="title", type=SearchFieldDataType.String,
                            searchable=True, retrievable=True),
            SearchableField(name="content", type=SearchFieldDataType.String,
                            searchable=True, retrievable=True),
            SearchField(name="content_vector", type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                            searchable=True, dimensions=1536, vector_search_configuration="my-vector-config"),
            SearchableField(name="metadata", type=SearchFieldDataType.String,
                            searchable=True, retrievable=True)
        ]

        vector_search = VectorSearch(
            algorithm_configurations=[
                VectorSearchAlgorithmConfiguration(
                    name="my-vector-config",
                    kind="hnsw",
                    hnsw_parameters={
                        "m": 4,
                        "efConstruction": 400,
                        "efSearch": 500,
                        "metric": "cosine"
                    }
                )
            ]
        )

        semantic_config = SemanticConfiguration(
            name="my-semantic-config",
            prioritized_fields=PrioritizedFields(
                title_field=SemanticField(field_name="title"),
                prioritized_content_fields=[SemanticField(field_name="content")]
            )
        )

        # Create the semantic settings with the configuration
        semantic_settings = SemanticSettings(configurations=[semantic_config])

        # Create the search index with the semantic settings and vector search
        index = SearchIndex(name=index_name, fields=fields,
                            vector_search=vector_search, semantic_settings=semantic_settings)
        index_client.create_index(index)
    
    return SearchClient(endpoint=endpoint, index_name=index_name, credential=AzureKeyCredential(key))


class AzureSearch(VectorStore):
    def __init__(
        self,
        azure_cognitive_search_name: str,
        azure_cognitive_search_key: str,
        index_name: str,
        embedding_function: Callable,
        **kwargs: Any,
    ):
        """Initialize with necessary components."""
        try:
            from azure.search.documents import SearchClient  
        except ImportError:
            raise ValueError(
                "Could not import requests python package. "
                "Please install it with `pip install dist/azure_search_documents-11.4.0b4-py3-none-any.whl`."
            )

        self.embedding_function = embedding_function
        self.client = get_search_client(azure_cognitive_search_name,azure_cognitive_search_key,index_name) #SearchClient(endpoint=service_endpoint, index_name=index_name, credential=credential)
    
    def add_texts(
        self,
        texts: Iterable[str],
        metadatas: Optional[List[dict]] = None,
        **kwargs: Any,
    ) -> List[str]:
        """Add texts data to an existing index."""
        keys = kwargs.get("keys")
        ids = []
        # Write data to index
        data = []
        for i, text in enumerate(texts):
            # Use provided key otherwise use default key
            key = keys[i] if keys else str(uuid.uuid4())
            metadata = metadatas[i] if metadatas else {}

            data.append({
                "@search.action": "upload",
                "id": key,
                "title": metadata.get("title", metadata.get("source", "[]").split('[')[1].split(']')[0]),
                "content": text,
                "content_vector": np.array(
                    self.embedding_function(text), dtype=np.float32
                ).tolist(),
                "metadata": json.dumps(metadata)
            })
            ids.append(key)

        response = self.client.upload_documents(documents=data)

        if all([r.succeeded for r in response]):
            return ids
        else:
            raise Exception(response)

    def similarity_search(
        self, query: str, k: int = 4, **kwargs: Any
    ) -> List[Document]:
        """
        Returns the most similar indexed documents to the query text.

        Args:
            query (str): The query text for which to find similar documents.
            k (int): The number of documents to return. Default is 4.

        Returns:
            List[Document]: A list of documents that are most similar to the query text.
        """
        docs_and_scores = self.similarity_search_with_score(query, k=k)
        return [doc for doc, _ in docs_and_scores]

    def similarity_search_with_score(
        self, query: str, k: int = 4
    ) -> List[Tuple[Document, float]]:
        """Return docs most similar to query.

        Args:
            query: Text to look up documents similar to.
            k: Number of Documents to return. Defaults to 4.

        Returns:
            List of Documents most similar to the query and score for each
        """                
        results = self.client.search(
            search_text="", 
            vector=Vector(value=np.array(self.embedding_function(query), dtype=np.float32).tolist(), k=k, fields="content_vector"),
            select=["title,content,metadata"]
        )


        docs = [
            (
                Document(
                    page_content=result['content'], metadata=json.loads(result['metadata'])
                ),
                1 - float(result['@search.score']),
            )
            for result in results
        ]

        return docs

    @classmethod
    def from_texts(
        cls: Type[AzureSearch],
        texts: List[str],
        embedding: Embeddings,
        azure_cognitive_search_name: str,
        azure_cognitive_search_key: str,
        metadatas: Optional[List[dict]] = None,
        index_name: Optional[str] = None,
        **kwargs: Any,
    ) -> AzureSearch:
        # Name of the search index if not given
        if not index_name:
            index_name = uuid.uuid4().hex

        client = get_search_client(azure_cognitive_search_name, azure_cognitive_search_key, index_name)
    
        keys = kwargs.get("keys")
        ids = []
        # Write data to index
        data = []
        for i, text in enumerate(texts):
            # Use provided key otherwise use default key
            key = keys[i] if keys else str(uuid.uuid4())
            metadata = metadatas[i] if metadatas else {}
            data.append({
                "@search.action": "upload",
                "id": key,
                "title": metadata.get("title", metadata.get("source", "[]").split('[')[1].split(']')[0]),
                "content": text,
                "content_vector": np.array(
                    embedding.embed_documents(text), dtype=np.float32
                ).tolist()[0],
                "metadata": json.dumps(metadata),
            })
            ids.append(key)
        response = client.upload_documents(documents=data)
        if all([r.succeeded for r in response]):
            return cls(azure_cognitive_search_name, azure_cognitive_search_key, index_name, embedding.embed_query)
        else:
            raise Exception(response)


class AzureSearchVectorStoreRetriever(BaseRetriever, BaseModel):
    vectorstore: AzureSearch
    search_type: str = "similarity"
    k: int = 4
    score_threshold: float = 0.4

    class Config:
        """Configuration for this pydantic object."""

        arbitrary_types_allowed = True

    @root_validator()
    def validate_search_type(cls, values: Dict) -> Dict:
        """Validate search type."""
        if "search_type" in values:
            search_type = values["search_type"]
            if search_type not in ("similarity"):
                raise ValueError(f"search_type of {search_type} not allowed.")
        return values
    
    def get_relevant_documents(self, query: str) -> List[Document]:
        if self.search_type == "similarity":
            docs = self.vectorstore.similarity_search(query, k=self.k)
        else:
            raise ValueError(f"search_type of {self.search_type} not allowed.")
        return docs

    async def aget_relevant_documents(self, query: str) -> List[Document]:
        raise NotImplementedError("AzureSearchVectorStoreRetriever does not support async")